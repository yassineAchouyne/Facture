

<?php $__env->startSection('haider'); ?>
<h2 class="text-primary">Facture F<?php echo e($facture->nbr_facture); ?></h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('action'); ?>

<li class="dropdown no-arrow mt-4 mr-3 ml-3">
    <a class="dropdown-toggle" href="/pdf/<?php echo e($facture->id_facture); ?>" role="button">
        <i class="bi bi-file-earmark-arrow-down-fill fa-md fa-fw text-gray-400"></i>
    </a>
</li>

<li class="dropdown no-arrow mt-4">
    <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <i class="fas fa-ellipsis-v fa-md fa-fw text-gray-400"></i>
    </a>
    <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">
        <a class="dropdown-item" href="/factures/<?php echo e($facture->id_facture); ?>/edit">Modifier</a>
        <a class="dropdown-item" href="#" data-toggle="modal" data-target="#popupdel">Supprimer</a>
        <?php if($facture->statut!="payer"): ?>
            <a class="dropdown-item" href="/statut/<?php echo e($facture->id_facture); ?>" >Facture est Payer</a>
        <?php endif; ?>
    </div>
    <!-- pupup supprimer -->
    <div class="modal fade" id="popupdel" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">

                <div class="modal-body">
                    Voulez-vous vraiment supprimer ce Fcture ?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Fermer</button>
                    <!-- <button type="button" class="btn btn-primary">Save changes</button> -->
                    <form action="/factures/<?php echo e($facture->id_facture); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("DELETE"); ?>
                        <input class="btn btn-success" type="submit" value="Supprimer" />
                    </form>
                </div>
            </div>
        </div>
</li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="m-1">
    <div class="m-2 row">
        <h5 class="pb-2">Informations</h5>
        <div class="m-2 border-bottom col-lg-6 pb-2 row">
            <span class="text-secondary col">Statut :</span>
            <?php if($facture->statut=="payer"): ?>
                <span class="ml-5 col badge badge-success"><?php echo e($facture->statut); ?></span>
            <?php else: ?>
                <span class="ml-5 col badge badge-danger"><?php echo e($facture->statut); ?></span>
            <?php endif; ?>
        </div>
        <div class="m-2 border-bottom col-lg-6 pb-2 row">
            <span class="text-secondary  col">Créée le :</span>
            <span class="ml-5  col"><?php echo e($facture->created_at); ?></span>
        </div>
        <div class="m-2 border-bottom col-lg-6 pb-2 row">
            <span class="text-secondary  col">Dernière modification le :</span>
            <span class="ml-5  col"><?php echo e($facture->updated_at); ?></span>
        </div>
    </div>
    <div class="m-2 row">
        <h5 class="pb-2">Destinataire</h5>
        <div class="m-2 border-bottom col-lg-6 pb-2 row">
            <span class="text-secondary  col">Destinataire :</span>
            <a href="/clients/<?php echo e($client->id_client); ?>" class="ml-5 text-decoration-none  col"><?php echo e($client->prenom . ' ' . $client->nom); ?></a>
        </div>
        <div class="m-2 border-bottom col-lg-6 pb-2 row">
            <span class="text-secondary  col">Adresse :</span>
            <span class="ml-5  col"><?php echo e($client->adresse . ' ' . $client->codePostal. ' ' . $client->ville); ?></span>
        </div>
        <div class="m-2 border-bottom col-lg-6 pb-2 row">
            <span class="text-secondary  col">Pays :</span>
            <span class="ml-5  col"><?php echo e($client->pays); ?></span>
        </div>
        <div class="m-2 border-bottom col-lg-6 pb-2 row">
            <span class="text-secondary  col">Numéro de téléphone :</span>
            <a href="tel:<?php echo e($client->tel); ?>" class="ml-5  col"><?php echo e($client->tel); ?></a>
        </div>
        <div class="m-2 border-bottom col-lg-6 pb-2 row">
            <span class="text-secondary  col">Adresse email :</span>
            <a href="mailto:<?php echo e($client->email); ?>" class="ml-5  col"><?php echo e($client->email); ?></a>
        </div>
        <div class="m-2 border-bottom col-lg-6 pb-2 row">
            <span class="text-secondary  col">mode de Payment :</span>
            <span class="ml-5  col"><?php echo e($facture->modePayment); ?></span>
        </div>
    </div>
    <div class="m-2 row table-responsive">
        <h5 class="pb-2">Détail</h5>
        <table style="min-width: 500px;" class="table">
            <tr>
                <td>Description</td>
                <td>Prix unitaire HT</td>
                <td>Quantité</td>
                <td>Total HT</td>
            </tr>
             <?php 
                $qtt = json_decode($facture->quantite, true);
                $pr = json_decode($facture->prixHT, true);
                $desc = json_decode($facture->Description, true);
             ?>

             <?php $__currentLoopData = $qtt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($desc[$i]); ?></td>
                <td><?php echo e($pr[$i]); ?> DH</td>
                <td><?php echo e($q); ?></td>
                <td><?php echo e($q * $pr[$i]); ?> DH</td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr class="  ">
                <td></td>
                <td></td>
                <td class="bg-secondary fw-bold">Total :</td>
                <td class="bg-secondary fw-bold"><?php echo e($function->totalHT($facture)); ?> DH</td>
            </tr>

        </table>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp\Desktop\GITHUP\Facture\resources\views/admin/showFacture.blade.php ENDPATH**/ ?>