

<?php $__env->startSection('haider'); ?>
<h2 class="text-primary"><?php echo e($client->prenom.' '.$client->nom); ?></h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('action'); ?>

<li class="dropdown no-arrow mt-4">
    <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <i class="fas fa-ellipsis-v fa-md fa-fw text-gray-400"></i>
    </a>
    <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">
        <a class="dropdown-item" href="/clients/<?php echo e($client->id_client); ?>/edit">Modifier</a>
        <a class="dropdown-item" href="#" data-toggle="modal" data-target="#popupdel">Supprimer</a>
    </div>
    <div class="modal fade" id="popupdel" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">

                <div class="modal-body">
                    Voulez-vous vraiment supprimer ce Fcture ?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Fermer</button>
                    <!-- <button type="button" class="btn btn-primary">Save changes</button> -->
                    <form action="/clients/<?php echo e($client->id_client); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("DELETE"); ?>
                        <input class="btn btn-success" type="submit" value="Supprimer" />
                    </form>
                </div>
            </div>
        </div>
    </div>
</li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="m-1">
    <div class="m-2 row">
        <h5 class="pb-2">Informations</h5>
        <div class="m-2 border-bottom col-lg-6 pb-2 row">
            <span class="text-secondary  col">Adresse email :</span>
            <a href="mailto:<?php echo e($client->email); ?>" class="ml-5  col"><?php echo e($client->email); ?></a>
        </div>
        <div class="m-2 border-bottom col-lg-6 pb-2 row">
            <span class="text-secondary  col">Numéro de téléphone :</span>
            <a href="tel:<?php echo e($client->tel); ?>" class="ml-5  col"><?php echo e($client->tel); ?></a>
        </div>
        <div class="m-2 border-bottom col-lg-6 pb-2 row">
            <span class="text-secondary  col">Adresse :</span>
            <span class="ml-5  col"><?php echo e($client->adresse . ' ' . $client->codePostal. ' ' . $client->ville); ?></span>
        </div>
        <div class="m-2 border-bottom col-lg-6 pb-2 row">
            <span class="text-secondary  col">Pays :</span>
            <span class="ml-5  col"><?php echo e($client->pays); ?></span>
        </div>
        <div class="m-2 border-bottom col-lg-6 pb-2 row">
            <span class="text-secondary  col">Site Web :</span>
            <a href="<?php echo e($client->website); ?>" target="_blank" class="ml-5  col"><?php echo e($client->website); ?></a>
        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp\Desktop\GITHUP\Facture\resources\views/admin/showClient.blade.php ENDPATH**/ ?>