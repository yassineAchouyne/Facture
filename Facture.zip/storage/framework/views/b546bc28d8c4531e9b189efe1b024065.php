

<?php $__env->startSection('haider'); ?>
<h2 class="text-primary">Les information</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style>
    .btnn {
        color: gray;
        background-color: #e4e4e4;
    }

    .btnn:hover {
        box-shadow: 1px 1px 5px gray;
        color: gray;
    }

    #lesButton {
        height: 90vh;
        display: flex;
        justify-content: center;
        align-items: center;
    }
</style>
<section class="w-100">
    <div id="lesButton">
        <div class="p-1 m-auto row" id="contactForme">
            <div id="btnClient" class="col-5  rounded border btn btnn" onclick="ToggleForm('client',this)">
                <div class="d-flex justify-content-center"><i class=" bi bi-person-circle fa-4x"></i></div><br>
                <div class=" text-center ">
                    <span class="h5">Auto Entrepreneur</span>
                </div>
            </div>
            <div class="col-2"></div>
            <div id="btnSociete" class="col-5  rounded border btn btnn" onclick="ToggleForm('societe',this)">
                <div class="d-flex justify-content-center"><i class=" bi bi-building fa-4x"></i></div><br>
                <div class=" text-center ">
                    <span class="h5">Société</span>
                </div>
            </div>
        </div>
    </div>

    <form id="contactForme" class="p-1 m-auto societe" action="/form" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" value="1" name="societe" />
        <!-- Name Societe input-->
        <div class="form-floating mb-3">
            <input class="form-control <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nom" name="nom" value="<?php echo e(old('nom')); ?>" type="text" placeholder="Enter your nom..." data-sb-validations="required" />
            <label for="nom" class="<?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> text-danger  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">Nom Sociéité </label>
        </div>

        <!--Address input-->
        <div class="form-floating mb-3">
            <input class="form-control <?php $__errorArgs = ['adresse'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="adresse" value="<?php echo e(old('adresse')); ?>" name="adresse" type="text" placeholder="Adresse" />
            <label for="adresse" class="<?php $__errorArgs = ['adresse'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> text-danger  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">Adresse </label>
        </div>
        <!--Code Postal input-->
        <div class="form-floating mb-3">
            <input class="form-control <?php $__errorArgs = ['codePostal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="codePostal" value="<?php echo e(old('codePostal')); ?>" name="codePostal" type="number" placeholder="code Postal" />
            <label for="codePostal" class="<?php $__errorArgs = ['codePostal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> text-danger  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">Code Postal </label>
        </div>
        <!--Ville input-->
        <div class="form-floating mb-3">
            <input class="form-control <?php $__errorArgs = ['ville'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="ville" value="<?php echo e(old('ville')); ?>" name="ville" type="text" placeholder="ville" />
            <label for="ville" class="<?php $__errorArgs = ['ville'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> text-danger  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">Ville</label>
        </div>
        <!--Pays select-->
        <div class="mb-3">
            <label class="ml-3" for="pays">Pays</label>
            <select style="height: 55px;" class="form-control selectpicker countrypicker" data-live-search="true" data-default="MA" name="pays" data-flag="true"></select>
        </div>
        <!--Site Internit input-->
        <div class="form-floating mb-3">
            <input class="form-control" id="site" name="website" type="url" placeholder="Site Internit" />
            <label for="ville">Site Internet</label>
        </div>

        <!-- fax input-->
        <div class="form-floating mb-3">
            <input class="form-control <?php $__errorArgs = ['fax'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="phone" value="<?php echo e(old('fax')); ?>" type="numbre" name="fax" placeholder="(123) 456-7890" />
            <label for="phone" class="<?php $__errorArgs = ['fax'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> text-danger  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">FAX </label>
        </div>
        <!--RC input-->
        <div class="form-floating mb-3">
            <input class="form-control <?php $__errorArgs = ['RC'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="RC" value="<?php echo e(old('RC')); ?>" name="RC" type="text" placeholder="RC" />
            <label for="ville" class="<?php $__errorArgs = ['RC'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> text-danger  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">RC</label>
        </div>
        <!--IF input-->
        <div class="form-floating mb-3">
            <input class="form-control <?php $__errorArgs = ['IF'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="IF" value="<?php echo e(old('IF')); ?>" name="IF" type="text" placeholder="RC" />
            <label for="ville" class="<?php $__errorArgs = ['IF'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> text-danger  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">IF</label>
        </div>
        <!--patent input-->
        <div class="form-floating mb-3">
            <input class="form-control <?php $__errorArgs = ['patent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="patent" value="<?php echo e(old('patent')); ?>" name="patent" type="text" placeholder="RC" />
            <label for="ville" class="<?php $__errorArgs = ['patent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> text-danger  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">Patent</label>
        </div>
        <!--cnss input-->
        <div class="form-floating mb-3">
            <input class="form-control <?php $__errorArgs = ['cnss'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="cnss" value="<?php echo e(old('cnss')); ?>" name="cnss" type="text" placeholder="RC" />
            <label for="ville" class="<?php $__errorArgs = ['cnss'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> text-danger  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">CNSS</label>
        </div>
        <!--ICF input-->
        <div class="form-floating mb-3">
            <input class="form-control <?php $__errorArgs = ['ICF'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="ICF" value="<?php echo e(old('ICF')); ?>" name="ICF" type="text" placeholder="RC" />
            <label for="ville" class="<?php $__errorArgs = ['ICF'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> text-danger  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">ICF</label>
        </div>
        <!-- avatar input -->
        <div class="mb-3">
            <label for="logo" class="ml-3 <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> text-danger  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">Logo de Societe </label>
            <input class="form-control <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="logo" type="file" name="logo" />
        </div>
        <!-- Submit Button-->
        <div class="d-grid"><button class="btn btn-primary btn-xl" id="submitButton" type="submit">Enregistrer</button></div>
    </form>

    <form id="contactForme" class="p-1 m-auto client" action="/form" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" value="0" name="societe" />
        <!--Address input-->
        <div class="form-floating mb-3">
            <input class="form-control <?php $__errorArgs = ['adresse'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="adresse" value="<?php echo e(old('adresse')); ?>" name="adresse" type="text" placeholder="Adresse" />
            <label for="adresse" class="<?php $__errorArgs = ['adresse'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> text-danger  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">Adresse </label>
        </div>
        <!--Code Postal input-->
        <div class="form-floating mb-3">
            <input class="form-control <?php $__errorArgs = ['codePostal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="codePostal" value="<?php echo e(old('codePostal')); ?>" name="codePostal" type="number" placeholder="code Postal" />
            <label for="codePostal" class="<?php $__errorArgs = ['codePostal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> text-danger  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">Code Postal </label>
        </div>
        <!--Ville input-->
        <div class="form-floating mb-3">
            <input class="form-control <?php $__errorArgs = ['ville'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="ville" value="<?php echo e(old('ville')); ?>" name="ville" type="text" placeholder="ville" />
            <label for="ville" class="<?php $__errorArgs = ['ville'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> text-danger  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">Ville</label>
        </div>
        <!--Pays select-->
        <div class="mb-3">
            <label class="ml-3" for="pays">Pays</label>
            <select style="height: 55px;" class="form-control selectpicker countrypicker" data-live-search="true" data-default="MA" name="pays" data-flag="true"></select>
        </div>
        <!--Site Internit input-->
        <div class="form-floating mb-3">
            <input class="form-control" id="site" name="website" type="url" placeholder="Site Internit" />
            <label for="ville">Site Internet</label>
        </div>

        <!--CNIE input-->
        <div class="form-floating mb-3">
            <input class="form-control <?php $__errorArgs = ['cnie'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="RC" value="<?php echo e(old('cnie')); ?>" name="cnie" type="text" placeholder="cnie" />
            <label for="ville" class="<?php $__errorArgs = ['cnie'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> text-danger  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">CNIE</label>
        </div>
        <!--IF input-->
        <div class="form-floating mb-3">
            <input class="form-control <?php $__errorArgs = ['IF'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="IF" value="<?php echo e(old('IF')); ?>" name="IF" type="text" placeholder="RC" />
            <label for="ville" class="<?php $__errorArgs = ['IF'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> text-danger  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">IF</label>
        </div>
        <!--taxe input-->
        <div class="form-floating mb-3">
            <input class="form-control <?php $__errorArgs = ['taxe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="taxe" value="<?php echo e(old('taxe')); ?>" name="taxe" type="text" placeholder="taxe" />
            <label for="ville" class="<?php $__errorArgs = ['taxe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> text-danger  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">Taxe professionnelle</label>
        </div>
        <!--ICF input-->
        <div class="form-floating mb-3">
            <input class="form-control <?php $__errorArgs = ['ICF'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="ICF" value="<?php echo e(old('ICF')); ?>" name="ICF" type="text" placeholder="RC" />
            <label for="ville" class="<?php $__errorArgs = ['ICF'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> text-danger  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">ICE</label>
        </div>

        <div class="d-grid"><button class="btn btn-primary btn-xl" id="submitButton" type="submit">Enregistrer</button></div>
    </form>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    var client = document.getElementsByClassName('client')[0];
    var societe = document.getElementsByClassName('societe')[0];
    var lesButton = document.getElementById('lesButton');
    societe.style.display = "none"
    client.style.display = "none"

    function ToggleForm(form, btn) {

        if (form == "client") {
            client.style.display = "block"
            societe.style.display = "none"
            lesButton.style.display = "none"
        } else {
            client.style.display = "none"
            societe.style.display = "block"
            lesButton.style.display = "none"
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp\Desktop\GITHUP\Facture\resources\views/admin/AjouterSociete.blade.php ENDPATH**/ ?>