

<?php $__env->startSection('content'); ?>
<form id="contactForme" class="p-1 m-auto" action="/clients/<?php echo e($client->id_client); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PATCH'); ?>
    <h4 class="text-center">Informations</h4>
    <!-- Email address input-->
    <div class="form-floating mb-3">
        <input class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" value="<?php echo e($client->email); ?>" name="email" required type="email" placeholder="name@example.com" data-sb-validations="required,email" />
        <label for="email">Adresse Email</label>
    </div>
    <!-- Prénom input-->
    <div class="form-floating mb-3">
        <input class="form-control <?php $__errorArgs = ['prenom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  value="<?php echo e($client->prenom); ?>" id="prenom" name="prenom" required type="text" placeholder="Enter your prenom..." data-sb-validations="required" />
        <label for="prenom">Prénom</label>
    </div>
    <!-- Name input-->
    <div class="form-floating mb-3">
        <input class="form-control" id="nom"  value="<?php echo e($client->nom); ?>" name="nom" required type="text" placeholder="Enter your nom..." data-sb-validations="required" />
        <label for="nom">Nom</label>
    </div>

    <h4 class="text-center mt-5">Coordonnées du client</h4>
    <!--Address input-->
    <div class="form-floating mb-3">
        <input class="form-control <?php $__errorArgs = ['adresse'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="adresse" name="adresse" value="<?php echo e($client->adresse); ?>"  type="text" placeholder="Adresse" data-sb-validations="required" />
        <label for="adresse">Adresse</label>
    </div>
    <!--Code Postal input-->
    <div class="form-floating mb-3">
        <input class="form-control <?php $__errorArgs = ['codePostal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="codePostal" name="codePostal" value="<?php echo e($client->codePostal); ?>"  type="number" placeholder="code Postal" data-sb-validations="required" />
        <label for="codePostal">Code Postal</label>
    </div>
    <!--Ville input-->
    <div class="form-floating mb-3">
        <input class="form-control <?php $__errorArgs = ['ville'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="ville" name="ville" value="<?php echo e($client->ville); ?>"  type="text" placeholder="ville" data-sb-validations="required" />
        <label for="ville">Ville</label>
    </div>
    <!--Pays select-->
    <div class="mb-3">
    <label class="ml-3" for="pays">Pays</label>
    <select class="form-control selectpicker countrypicker" data-default="<?php echo e($client->pays); ?>" name="pays"  data-flag="true"></select>
    </div>
     <!--Site Internit input-->
     <div class="form-floating mb-3">
        <input class="form-control" id="site" name="website" type="url" value="<?php echo e($client->website); ?>"  placeholder="Site Internit" data-sb-validations="required" />
        <label for="ville">Site Internet</label>
    </div>
    
    <!-- Phone number input-->
    <div class="form-floating mb-3">
        <input class="form-control <?php $__errorArgs = ['tel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="phone" type="numbre" name="tel" value="<?php echo e($client->tel); ?>"  placeholder="(123) 456-7890" data-sb-validations="required" />
        <label for="phone">Numéro de Téléphone</label>
    </div>

    <!-- Submit Button-->
    <div class="d-grid"><button class="btn btn-primary btn-xl" id="submitButton" type="submit">Modifier le client</button></div>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp\Desktop\GITHUP\Facture\resources\views/admin/modifierClient.blade.php ENDPATH**/ ?>