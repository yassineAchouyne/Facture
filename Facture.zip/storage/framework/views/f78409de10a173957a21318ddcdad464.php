

<?php $__env->startSection('haider'); ?>
<h2 class="text-primary">Nouvelle client</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- <style>
    .btnn{
        color: gray;
    }
    .btnn:hover {
        box-shadow: 1px 1px 5px gray;
        color: gray;
    }
</style> -->
<!-- <div class="p-1 m-auto row" id="contactForme">
    <div id="btnClient" class="col-5  rounded border btn btnn" onclick="ToggleForm('client',this)">
        <div class="d-flex justify-content-center"><i class=" bi bi-person-circle fa-2x"></i></div><br>
        <div class=" text-center ">
            <span class="h6">client sans société</span>
        </div>
    </div>
    <div class="col-2"></div>
    <div id="btnSociete" class="col-5  rounded border btn btnn" onclick="ToggleForm('societe',this)">
        <div class="d-flex justify-content-center"><i class=" bi bi-building fa-2x"></i></div><br>
        <div class=" text-center ">
            <span class="h6">client avec société</span>
        </div>
    </div>
</div> -->

<form id="contactForme" class="p-1 m-auto client" action="/clients" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

    <!-- Email address input-->
    <div class="form-floating mb-3">
        <input class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>" id="email" name="email" type="email" placeholder="name@example.com" />
        <label for="email" class="<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> text-danger  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">Adresse Email </label>
    </div>
    <!-- Prénom input-->
    <div class="form-floating mb-3">
        <input class="form-control <?php $__errorArgs = ['prenom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('prenom')); ?>" id="prenom" name="prenom" type="text" placeholder="Enter your prenom..." data-sb-validations="required" />
        <label for="prenom" class="<?php $__errorArgs = ['prenom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> text-danger  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">Prénom </label>
    </div>
    <!-- Name input-->
    <div class="form-floating mb-3">
        <input class="form-control <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nom" name="nom" value="<?php echo e(old('nom')); ?>" type="text" placeholder="Enter your nom..." data-sb-validations="required" />
        <label for="nom" class="<?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> text-danger  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">Nom </label>
    </div>

    <!--Address input-->
    <div class="form-floating mb-3">
        <input class="form-control <?php $__errorArgs = ['adresse'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="adresse" value="<?php echo e(old('adresse')); ?>" name="adresse" type="text" placeholder="Adresse" />
        <label for="adresse" class="<?php $__errorArgs = ['adresse'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> text-danger  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">Adresse </label>
    </div>
    <!--Code Postal input-->
    <div class="form-floating mb-3">
        <input class="form-control <?php $__errorArgs = ['codePostal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="codePostal" value="<?php echo e(old('codePostal')); ?>" name="codePostal" type="number" placeholder="code Postal" />
        <label for="codePostal" class="<?php $__errorArgs = ['codePostal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> text-danger  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">Code Postal </label>
    </div>
    <!--Ville input-->
    <div class="form-floating mb-3">
        <input class="form-control <?php $__errorArgs = ['ville'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="ville" value="<?php echo e(old('ville')); ?>" name="ville" type="text" placeholder="ville" />
        <label for="ville" class="<?php $__errorArgs = ['ville'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> text-danger  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">Ville</label>
    </div>
    <!--Pays select-->
    <div class="mb-3">
        <label class="ml-3" for="pays">Pays</label>
        <select style="height: 55px;" class="form-control selectpicker countrypicker" data-live-search="true" data-default="MA" name="pays" data-flag="true"></select>
    </div>
    <!--Site Internit input-->
    <div class="form-floating mb-3">
        <input class="form-control" id="site" name="website" type="url" placeholder="Site Internit" />
        <label for="ville">Site Internet</label>
    </div>

    <!-- Phone number input-->
    <div class="form-floating mb-3">
        <input class="form-control <?php $__errorArgs = ['tel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="phone" value="<?php echo e(old('tel')); ?>" type="numbre" name="tel" placeholder="(123) 456-7890" />
        <label for="phone" class="<?php $__errorArgs = ['tel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> text-danger  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">Numéro de Téléphone </label>
    </div>
    
    <!-- Submit Button-->
    <div class="d-grid"><button class="btn btn-primary btn-xl" id="submitButton" type="submit">Créer le client</button></div>
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    var client = document.getElementsByClassName('client')[0];
    var societe = document.getElementsByClassName('societe')[0];
    var btnClient = document.getElementById('btnClient');
    var btnSociete = document.getElementById('btnSociete');
    // societe.style.display = "none"
    // client.style.display = "none"
    function ToggleForm(form, btn) {

        if (form == "client") {
            client.style.display = "block"
            societe.style.display = "none"
            btn.style.backgroundColor = "#4e73df"
            btnSociete.style.backgroundColor="#fff"
            btnSociete.style.color="gray"
            btn.style.color="#fff"
        } else {
            client.style.display = "none"
            societe.style.display = "block"
            btn.style.backgroundColor = "#4e73df"
            btnClient.style.backgroundColor="#fff"
            btnClient.style.color="gray"
            btn.style.color="#fff"
        }


    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp\Desktop\GITHUP\Facture\resources\views/Admin/AjouterClient.blade.php ENDPATH**/ ?>